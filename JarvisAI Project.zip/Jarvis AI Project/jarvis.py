#Project on Jarvis AI Bot using Python

import speech_recognition as sr
import pyttsx3
import webbrowser
import openai
from playsound import playsound
import os
import pyautogui
from datetime import datetime


# Initialize speech engine globally
engine = pyttsx3.init()

# Speak function
def say(text):
    print(f"Jarvis: {text}")
    engine.say(text)
    engine.runAndWait()

# Listen function
def takeCommand():
    r = sr.Recognizer()
    with sr.Microphone() as source:
        print("Listening...")
        r.adjust_for_ambient_noise(source, duration=1)
        r.pause_threshold = 1
        audio = r.listen(source)

        try:
            print("Recognizing...")
            query = r.recognize_google(audio, language="en-in")
            print(f"User said: {query}")
            return query
        except sr.UnknownValueError:
            print("Could not understand audio.")
            say("I didn't catch that.")
            return ""
        except sr.RequestError:
            print("Could not connect to Google API.")
            say("Internet error.")
            return ""

# List of sites
sites = [
    ["google", "https://www.google.com"],
    ["youtube", "https://www.youtube.com"],
    ["wikipedia", "https://www.wikipedia.org"],
    ["facebook", "https://www.facebook.com"],
    ["twitter", "https://www.twitter.com"],
    ["instagram", "https://www.instagram.com"],
    ["gmail", "https://mail.google.com"],
    ["amazon", "https://www.amazon.in"],
    ["flipkart", "https://www.flipkart.com"],
    ["linkedin", "https://www.linkedin.com"],
    ["whatsapp", "https://web.whatsapp.com"],
    ["chatgpt", "https://chat.openai.com"]
]

# Main block
if __name__ == "__main__":
    print("PyCharm")
    say("Hello, I am Jarvis AI")

    while True:
        query = takeCommand()

        if not query:
            continue

        # Exit condition
        if "exit" in query.lower() or "stop" in query.lower():
            say("Goodbye! Have a great day.")
            break

        # Open websites
        opened = False
        for site in sites:
            if f"open {site[0]}" in query.lower():
                say(f"Opening {site[0]}")
                webbrowser.open(site[1])
                opened = True
                break

            # 🔽 Add your app-opening code right here
            if "open youtube" in query.lower():
                say("Opening YouTube")
                webbrowser.open("https://www.youtube.com")


            if "open notepad" in query.lower():
                say("Opening Notepad")
                os.system("notepad.exe")

            if "open calculator" in query.lower():
                say("Opening Calculator")
                os.system("calc.exe")

            if "open paint" in query.lower():
                say("Opening Paint")
                os.system("mspaint.exe")

            if "open command prompt" in query.lower() or "open cmd" in query.lower():
                say("Opening Command Prompt")
                os.system("cmd")

            if "open control panel" in query.lower():
                say("Opening Control Panel")
                os.system("control")

            if "open snipping tool" in query.lower():
                say("Opening Snipping Tool")
                os.system("snippingtool")
            # 🔼 Add more apps as needed

            if "exit" in query.lower():
                say("Goodbye")
                break

            #Date and Time
            if "date" in query.lower():
                current_date = datetime.now().strftime("%B %d, %Y")
                say(f"Today's date is {current_date}")
                print(f"Date: {current_date}")

            if "time" in query.lower():
                current_time = datetime.now().strftime("%I:%M %p")
                say(f"The current time is {current_time}")
                print(f"Time: {current_time}")

            if "exit" in query.lower():
                say("Goodbye")
                break

            #Open Folder
            if "open downloads" in query.lower():
                say("Opening Downloads folder")
                os.startfile("Downloads")

            if "open desktop" in query.lower():
                say("Opening Desktop folder")
                os.startfile(r"C:\Users\savita\OneDrive\Documents\Desktop")

            if "open documents" in query.lower():
                say("Opening Documents folder")
                os.startfile("C:\\Users\\savita\\OneDrive\\Documents")

            if "exit" in query.lower():
                say("Goodbye")
                break

            #Play Music Songs
            if "play music" in query.lower():
                say("Playing music")
                playsound(r"C:\Users\savita\OneDrive\Music\Playlists\Agajanana Padmarkam _ Shri Ganesha Slokam __(M4A_128K).m4a")

            if "play music" in query.lower():
                say("Playing music")
                playsound(r"C:\Users\savita\OneDrive\Music\Playlists\Deedar Hua (Full Video) Chitranshi Ft. Laqshay Kapoor _ Mohit Hiranandani _ Manpreet Kaur _ New Song(M4A_128K).m4a")

            if "play music" in query.lower():
                say("Playing music")
                playsound(r"C:\Users\savita\OneDrive\Music\Playlists\Gerua - Diwale _ _pritam7415 _ _SoulfulArijitSingh _ Antara Mitra _ Amitabh Bhattacharya _ SRK _ 4K(M4A_128K).m4a")

            if "exit" in query.lower():
                say("Goodbye")
                break

            #Take Screenshot
            if "take screenshot" in query.lower():
                say("Taking screenshot")
                screenshot = pyautogui.screenshot()
                screenshot.save(r"C:\Users\savita\Pictures\screenshot.png")
                say("Screenshot saved in Pictures folder.")

            if "exit" in query.lower():
                say("Goodbye")
                break


        if not opened:
            say(f"You said: {query}")

